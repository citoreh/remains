# What Remains of Today — Chrome Extension

A calm countdown ring for what's left of today, this week, month, quarter,
and year. Lives in your toolbar as a popup, with an optional full-page
focus view.

## Install (unpacked / developer mode)

Chrome extensions built outside the Web Store are installed via "Load
unpacked":

1. Unzip this folder somewhere permanent (don't delete it later — Chrome
   loads the extension from these files).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the unzipped `remains-of-today`
   folder (the one containing `manifest.json`).
5. Pin it: click the puzzle-piece icon in the toolbar, then the pin next
   to "What Remains of Today".

To publish it properly on the Chrome Web Store later, zip the folder
contents (not the folder itself) and upload via the Developer Dashboard —
no code changes needed.

## How it works

- **Toolbar popup** (click the icon): a compact view — main ring, four
  mini rings (week/month/quarter/year), and a settings panel. Fast to
  check, doesn't take over your screen.
- **Full-page view**: click the ↗ icon in the popup, or right-click the
  toolbar icon → *Options*. Recreates the original spacious layout, with
  fullscreen (`F`) and screen-wake-lock for use as an ambient display on
  a second monitor or in a pinned tab.
- **Toolbar badge**: the icon itself shows a live "% left" or "Nh"
  reading, updated every minute, colored by your accent theme (red in
  the final hour) — so you get a glance-and-go read without opening
  anything. Turn it off in Settings → Toolbar badge if you'd rather it
  stay quiet.
- **Settings sync**: end-of-day anchor, accent color, badge style, and
  time zone are stored with `chrome.storage.sync`, so they follow you
  across Chrome instances signed into the same account, and stay
  identical between the popup and full-page view.

## What I changed from the original single HTML file

- **Split into a popup + full page** rather than one page, since a
  toolbar popup can't reasonably show the same wide three-column layout
  and can't use Fullscreen/Wake Lock (both are blocked in that context).
  The full layout, fullscreen, and wake-lock all still exist — just in
  the full-page tab.
- **Added the toolbar badge** (new) via a small background service
  worker + `chrome.alarms`, since a glanceable badge is the single
  highest-leverage feature for something living in the toolbar — most of
  the time you won't need to open anything at all.
- **Swapped Google Fonts for system fonts.** The original pulled
  Fraunces/Space Grotesk from `fonts.googleapis.com`. For a popup that
  needs to render instantly and work offline, an external font request
  on every open is a bad trade for a fairly small type-style gain, so
  this uses the OS's UI font stack with italic serif fallbacks for the
  same feel.
- **`chrome.storage.sync` instead of `localStorage`** so settings
  persist correctly in the extension's storage partition and sync
  across your devices.
- **Added keyboard shortcuts** at the Chrome level (`chrome://extensions/
  shortcuts`): a default open-popup shortcut and one to jump straight to
  the full-page view, in addition to the in-page `F`/`S`/`Esc` shortcuts
  from the original.

## Files

```
manifest.json       Extension manifest (MV3)
popup.html/.js       Toolbar popup
fullpage.html         Full-page focus view (also the Options page)
css/style.css         Shared visual styles
css/popup.css         Popup-only layout
css/fullpage.css      Full-page-only layout
js/clock.js           Shared countdown/ring/settings logic
js/background.js      Service worker — keeps the toolbar badge live
icons/                Toolbar + store icons (16/32/48/128px)
```
