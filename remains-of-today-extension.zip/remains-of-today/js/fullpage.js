(function(){
  "use strict";
  window.WhatRemains.RemainingClock(document, { enableFullscreen: true, setTitle: true });
})();
