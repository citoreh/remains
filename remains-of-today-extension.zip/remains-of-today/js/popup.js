(function(){
  "use strict";
  window.WhatRemains.RemainingClock(document, { enableFullscreen: false, setTitle: false });

  function openFullPage(){
    const url = chrome.runtime.getURL('fullpage.html');
    chrome.tabs.create({ url });
    window.close();
  }

  const expandBtn = document.getElementById('expandBtn');
  const openFull = document.getElementById('openFull');
  if (expandBtn) expandBtn.addEventListener('click', openFullPage);
  if (openFull) openFull.addEventListener('click', e => { e.preventDefault(); openFullPage(); });
})();
