// Background service worker for "What Remains of Today".
// Keeps a live badge on the toolbar icon (e.g. "62%" or "9h") so the user
// can glance at time-remaining without opening the popup, and refreshes
// once a minute plus whenever settings change.
"use strict";

const DEFAULT_STATE = { theme: 'amber', anchor: 'midnight', tz: 'local', badge: 'percent' };
const THEMES = { amber: '#ff9a5b', teal: '#34b3a0', violet: '#8a6bff', mono: '#aab6d4' };
const ALARM_NAME = 'wrt-tick';

function anchorSeconds(state){
  if (state.anchor === 'midnight' || state.anchor === '24:00') return 86400;
  const m = /^(\d{1,2}):(\d{2})$/.exec(state.anchor);
  if (!m) return 86400;
  let s = (+m[1]) * 3600 + (+m[2]) * 60;
  if (s <= 0 || s > 86400) s = 86400;
  return s;
}

function getWall(now, state){
  if (state.tz === 'local') return now;
  try{
    const fmt = new Intl.DateTimeFormat('en-US', { timeZone: state.tz, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const p = {}; for (const part of fmt.formatToParts(now)) p[part.type] = part.value;
    return new Date(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second, now.getMilliseconds());
  } catch(e){ return now; }
}

async function getState(){
  return new Promise(resolve => {
    chrome.storage.sync.get(DEFAULT_STATE, items => {
      if (chrome.runtime.lastError) { resolve({ ...DEFAULT_STATE }); return; }
      resolve(items);
    });
  });
}

async function updateBadge(){
  const state = await getState();
  if (state.badge === 'off'){
    chrome.action.setBadgeText({ text: '' });
    return;
  }

  const now = new Date();
  const wall = getWall(now, state);
  const secIntoDay = wall.getHours() * 3600 + wall.getMinutes() * 60 + wall.getSeconds();
  const total = anchorSeconds(state);
  const secLeft = Math.max(0, total - secIntoDay);
  const frac = total > 0 ? secLeft / total : 0;
  const finalHour = secLeft > 0 && secLeft <= 3600;

  let text;
  if (state.badge === 'hours'){
    const h = Math.ceil(secLeft / 3600);
    text = secLeft <= 0 ? '0h' : `${h}h`;
  } else {
    text = secLeft <= 0 ? '0%' : `${Math.round(frac * 100)}%`;
  }

  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: finalHour ? '#ff4d4d' : (THEMES[state.theme] || THEMES.amber) });
  try{ chrome.action.setBadgeTextColor({ color: '#0a0e1a' }); } catch(e){ /* older Chrome */ }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  updateBadge();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  updateBadge();
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM_NAME) updateBadge(); });
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'sync') updateBadge(); });

chrome.commands.onCommand.addListener(command => {
  if (command === 'open-full-page'){
    chrome.tabs.create({ url: chrome.runtime.getURL('fullpage.html') });
  }
});

updateBadge();
